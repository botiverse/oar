# @botiverse/oar

Provider-independent TypeScript contracts and adapters for controlling and observing Antigravity, Claude, Codex, CodeBuddy, DeepSeek Harness, Devin, Factory Droid, Grok, Kimi, OpenCode, Pi, Qwen Code, and Qoder (plus optional-peer Cursor and Pi Durable, and community Mister Morph and Cybion).

```ts
import { defaultRuntimes, promptAndWait } from "@botiverse/oar";

const runtime = defaultRuntimes.require("grok");
const installation = await runtime.installation?.();

if (installation?.kind === "available") {
  const session = await runtime.session(installation, { cwd: process.cwd() });
  session.events((event) => {
    switch (event.kind) {
      case "text_delta": process.stdout.write(event.text); break;
      case "tool_call_started": console.log(`[${event.tool}]`); break;
      case "turn_ended": console.log(event.outcome.kind); break;
    }
  }, { coalesceText: true });
  const run = await promptAndWait(session, "Inspect this repository");
  console.log("outcome" in run ? run.outcome : run.kind);
  console.log(session.usage(), await runtime.accountUsage?.(installation));
  await session.dispose();
}
```

`promptAndWait` uses your `inputId`, or generates a UUID, to associate native
queued/started reports with its answer. A notification turn before the input
starts does not satisfy that wait. Without those native reports it keeps the
request-based fallback. For a lower-level wait, pass the inputId to
`awaitTurnEnd(session, requestSeq, inputId)`; omitting it waits for the first
root turn end after that cursor. `session.prompt()` already generates an id
when omitted; it is recorded on the returned prompt request. A native
before-start cancellation resolves an input-scoped wait as `aborted`, even
without a turn-end event. When the runtime handles the input natively without
a model turn (Pi, for an extension command), `promptAndWait` returns
`kind: "handled"` with the `input_handled` disposition; that is not success.
`awaitIdle` waits through an intervening notification while a host prompt
remains pending.

`session.events()` delivers flat, attributed `Event`s (native user message
echoes, text, reasoning, tool call start / later input / progress / end, turn
start and end, usage, model, effort, compaction start / end, retry, background
tasks and subagents started, updated and ended, runtime→app requests and oar's
answers, control rejections, withdrawn and natively handled inputs, the process
exit), each carrying the `seq` and `agentPath` of the record it was read from.
Kinds a runtime never says never appear (some runtimes report no
compaction start, some no compaction, and several no retry); the
[runtime matrix](https://github.com/botiverse/oar/blob/main/docs/spec/runtime-matrix.md)
and the runtime pages say which. It is a
projection over the record stream, which `session.rawEvents()` and
`session.records()` expose (`RawEvent`: `Frame` with the native payload
verbatim, `RequestRecord`, `ResponseRecord`) for consumers who need the
runtime's own frames. `SessionOptions.retainedBytes` bounds what the process
retains: past it the oldest frames lose `native` and tool input and output and
carry `elided: true`, while live observers still receive every record complete
([bounding retained records](https://github.com/botiverse/oar/blob/main/docs/spec/record-stream.md#bounding-retained-records)).
`tool_call_ended.exitCode` is the exit status a runtime
reports for a command it ran, absent where it reports none (claude); see
[tool outcomes](https://github.com/botiverse/oar/blob/main/docs/spec/runtime-matrix.md#tool-outcomes).
In `session.usage()`, `TokenTotals.reasoning` is the part of `output` the
runtime reports as reasoning (absent where the runtime does not report it;
the linked section lists which do): never add it to `output` again
([reasoning tokens](https://github.com/botiverse/oar/blob/main/docs/spec/attribution.md#reasoning-tokens)).

Tool arguments can arrive while the model is still writing them. Append
`tool_call_input_delta.delta` as raw text; `tool_call_input.input` replaces
the whole input when complete. `SessionView` does this for you, marking a
tool's preview with `inputPartial: true` until the complete input arrives.
Claude's streamed `tool_call_started` carries no input, so read the later
input event before parsing arguments. Calls without a partial stream still
start with their complete input.

`session.deliver(input, { when, origin })` sends input the host produces (a
subagent's result, a finished job) at the right moment: a new turn when the
session is idle, so the agent wakes, otherwise steered into the turn or queued
behind it. `origin` is recorded so a UI can tell it from typed input.
`when: "interrupt"` (with `maxWaitMs` and an optional `merge`) steers where
the session can; otherwise it needs `withdraw`, waits up to `maxWaitMs` for
root tools, withdraws the held inputs, aborts the turn and, after the
runtime's own turn end, sends them as one merged prompt
([interrupting](https://github.com/botiverse/oar/blob/main/docs/spec/conversation.md#interrupting-and-merging-held-inputs)).
`session.steer` exists only on a session whose runtime can steer (qwen,
codebuddy, devin and kimi ACP fallback sessions have none, nor opencode v2
sessions whose `initialize` does not advertise steering or dsh sessions without
`steer` in their native method inventory; kimi KAP sessions expose `steer`; see
[session controls](https://github.com/botiverse/oar/blob/main/docs/spec/runtime-matrix.md#session-controls)),
so a host offers a steer control by reading the member, never a runtime
name; `deliver` and `steerOrQueue` queue where it is absent. Before any session
exists, `runtime.sessionCapabilities?.(installation)` answers synchronously
what that installation will offer: `steer`, `images`, the options it refuses,
manual compaction and compaction events, where known without opening one; an
absent field is unknown, not false
([before open](https://github.com/botiverse/oar/blob/main/docs/spec/runtime-matrix.md#session-capabilities-before-open)).
`session.withdraw(inputId)` takes a queued input back before it is
sent (`accepted`), or answers `not_queued` once it went; with it a UI offers
withdraw, edit (withdraw, then `queue` again) and send now (withdraw, then
`deliver`). It exists where OAR holds the queue itself (claude, pi, qwen, qoder, cursor,
factory, kimi, morph, cybion and the ACP runtimes), on pi-durable through native submission cancellation and on
dsh through native inbox removal where its method inventory advertises it, not on codex.
`session.stopTask(taskId)` stops one native task without aborting its parent
(claude, codex, qoder, kimi KAP, and dsh for backgrounded shell jobs where job controls are advertised); acceptance is the native acknowledgement, never a task
end ([single-task stop](https://github.com/botiverse/oar/blob/main/docs/spec/runtime-matrix.md#native-tasks-and-single-task-stop)).
`session.compact()` is optional on Claude, Codex, Pi SDK/RPC, Grok, Qoder,
Cursor, Factory, Kimi KAP, DSH (when supported) and OpenCode v2 sessions. OpenCode v1 and Kimi ACP omit it.
`runtime.manualCompaction` describes support and active-turn policy; these
implementations require idle sessions. The result distinguishes native
completion, failure, cancellation, rejection and an unconfirmed wait.
`timeoutMs` or `signal` stops waiting without stopping native work, and the
session remains busy until native completion or session loss. See
[manual compaction](https://github.com/botiverse/oar/blob/main/docs/spec/manual-compaction.md).
Claude's `turn_ended.inputId?` and `inputIds?` copy its independently reported
singular and plural input identities. Use the full `inputIds` list when
marking a merged native turn's inputs complete; neither field is inferred.

`session.resources()` reads the memory a runtime takes on the host: resident
bytes and a process count over the runtime process, its group and its
descendants, `null` once it has exited (and on Windows). It is a reading only,
never a handle: no pid leaves OAR. Pi's default SDK mode, pi-durable, cursor (in either execution mode), morph and cybion have none.

For conversation UIs, use the browser-safe `reduceConversation` projection
over `session.rawEvents()`. It joins input requests, responses and native
echoes by identity, including steer → queue fallback. See the
[conversation contract](https://github.com/botiverse/oar/blob/main/docs/spec/conversation.md).

`failureAdvice` suggests **when to retry**, based only on the failure class.
It does not establish that repeating an input or an entire turn is safe:
tools may already have run and files may already have changed. A host can
collect the evidence for its own recovery decision:

```ts
import { failureAdvice, type ConversationInput, type FailureClass, type Session } from "@botiverse/oar";

function recoveryEvidence(failure: FailureClass, input: ConversationInput, reopened: Session) {
  return {
    timing: failureAdvice(failure),
    inputState: input.state,
    dropReason: input.state === "dropped" ? input.reason : undefined,
    recordsAfterReopening: reopened.records(),
  };
}
```

An accepted input should not be resubmitted without a later drop. Even
`dropped` with `reason: "runtime_exited"` means only that no input echo was
observed before exit; a durable queue may still hold it. Inspect the reopened
session's records and what the runtime can restore before deciding to resend.
See [dropped input](https://github.com/botiverse/oar/blob/main/docs/spec/conversation.md#dropped-input).

## Public exports

The package has these public entry points, plus `@botiverse/oar/pi-durable` ([below](#host-owned-durable-sessions)) and `@botiverse/oar/community` for community runtimes (below):

- `@botiverse/oar`: the runtime registry and adapters, bounded `orient` snapshots, `defineRuntime`, `UnsupportedOptionError` (and its `ResumeCwdError` subclass), `ModelConfirmationError`, `RuntimeFailureError`, `SessionNotFoundError`, `SessionUnavailableError`, `serveMcpTools`, `userShellEnvironment` and `writeShellEnvironmentCapture`, the `oar-voyage/3` recorder (`openVoyage`), and everything the brands and observe entry points below export. Node-only (adapters import `node:child_process` and runtime SDKs).
- `@botiverse/oar/browser`: portable contracts, registry, session kernel, observe helpers, agent report formatting, and branding. No Node adapters, process helpers or local image-file loaders.
- `@botiverse/oar/brands`: browser-safe runtime names and SVG icons.
- `@botiverse/oar/runtimes/<id>` (`claude`, `codex`, `codebuddy`, `devin`, `dsh`, `factory`, `hermes`, `pi`, `cursor`, `opencode`, `kimi`, `grok`, `antigravity`, `qwen`, `qoder`): one built-in runtime (`claudeRuntime`, …; cursor's is `createCursorRuntime`) without the others, for a host that needs only some of them (plus `@botiverse/oar/runtimes/codex/installation-candidates` for Codex executable candidate probing; `./runtimes/pi-durable` is blocked in favor of `@botiverse/oar/pi-durable`). Each entry stays at about 1 to 2.5 MB of heap where the root entry takes about 50 MB (Node 26, [#405](https://github.com/botiverse/oar/pull/405)): the ACP SDK (about 20 MB) loads only on the first call that speaks ACP (a session, a model list, a usage, sign-in or status read on an ACP entry, the Qwen provider facade), and the pi and cursor SDKs when theirs first run. Node-only.
- `@botiverse/oar/observe`: the browser-safe pure derivations over `RawEvent`s and `Event`s (`eventsOf`, `graphOf`, `usageOf`, `observeAgent`, `reduceStatus`, `tasksOf`, `observeStalls`, `classifyTool`, `reduceConversation`, `reduceSessionView`, `queueSnapshotOf`, `queueSnapshotPlan`, `restoreQueue`, …) with no Node or adapter imports, so a browser or Electron-renderer bundle can import it directly. The root export re-exports all of them.
  A [queue snapshot](https://github.com/botiverse/oar/blob/main/docs/spec/queue-snapshot.md) is the host-owned durable queue: OAR derives it from records the host already keeps, validates it on read, and restores through the ordinary `Session.queue` call, sending only input the stream returned to the caller. OAR stores nothing and never resends on its own.
  It also supplies `failureAdvice` (recovery timing per `FailureClass`) and `noticeText`, `noticeTone`, `phaseLabel`, `failureText` and `taskStatusLabel`, alongside `toolActionLabel` and `toolGroupSummary`: English display wording for OAR types, usable in JavaScriptCore too. Wording may change in a minor release; hosts must use the typed values for decisions, not parse the text ([display wording](https://github.com/botiverse/oar/blob/main/docs/spec/conversation.md#display-wording)).
- `@botiverse/oar/kernel`: the runtime-author SPI. `createSessionKernel` is the record stream every built-in adapter is built on (dense `seq`, cursor replay, control recording, the reachability rule) and `sealSession` derives the `Session` API face over an adapter. Pair with `defineRuntime` to ship a custom runtime (a scripted runtime for a host's tests, an in-process agent) without re-implementing the stream contract. `inputImagesRefusal` and `withInputImages` apply the image rules every built-in runtime keeps, so a custom runtime refuses the inputs they refuse. `withdrawHeld` applies `Session.withdraw` to an adapter-held queue; its `HeldInput` type is public too.
- `@botiverse/oar/agents`: subagents. `createSubagents()` starts child sessions on any runtime that takes `SessionOptions.env` (not in-process cursor, pi-durable, morph or cybion), returns a report for every turn they end, takes follow-ups, enforces depth and concurrency limits, and reports each child as a task. The host takes reports with `wait` / `next` or receives them through an `onReport` hook; with `formatReport` and `reportOrigin` it can `deliver` one into a parent session so it wakes. See [subagents](https://github.com/botiverse/oar/blob/main/docs/spec/subagents.md). Node-only.
- `@botiverse/oar/agents/report`: `formatReport`, `parseReport`, `reportOrigin` and their types, with no Node or adapter imports, for a host forwarding or displaying reports. `parseReport` reads the existing report format into header fields, a structured outcome and the original body, or returns `null`. `@botiverse/oar/agents` loads every built-in runtime, because `createSubagents` defaults to them.
- `@botiverse/oar/testing`: `scriptedRuntime({ turn })`, a ready-made runtime on the kernel SPI whose model is a script. It yields a real `Session` (same records, folds and control semantics) with no binary, login or provider, for hosts' tests and demos. A script can also start tasks (`turn.task`) that end after the turn, like a background command, and make the runtime's process exit on its own (`turn.exit`, during the turn or kept for later, while idle), recorded as a vendor process's unexpected exit is. Node-only.
- `@botiverse/oar/forms`: runtime config forms for a host's agent-creation UI, as plain data (`configForms`, keyed by runtime id; grok only so far) and shared form types. Hosts validate and map selected values to session options. A form states what the runtime accepts; a host may only narrow it. Loads no runtime SDK and does nothing on import, so it runs in a browser. See [config form](https://github.com/botiverse/oar/blob/main/docs/spec/config-form.md).
- `@botiverse/oar/capabilities`: `installedSessionCapabilities` and its session-capability contract types (`SessionCapabilityDeclaration`, `CompactionEvents`, `ManualCompaction`, `ContextUsageCapability`, `McpTransport`, `RefusedSessionOptions`, `RefusableSessionOption`, `AvailableInstallation`, `Runtime`). Loads only contract modules, no runtime adapters or native SDKs, for hosts that avoid the root entry to keep memory low.

Brand SVGs (`<runtime-id>.svg`, plus themed `*-on-light.svg`/`*-on-dark.svg` variants and `NOTICE.md`) are exported under `@botiverse/oar/assets/brands/*`. Any other deep import (`@botiverse/oar/dist/...`, source paths) is internal and may break without notice.

Antigravity, CodeBuddy, Devin, Grok, Hermes, Kimi (ACP fallback), and OpenCode share an internal ACP v1 transport and session kernel, but only their concrete runtime identities are public. The registry deliberately does not expose a generic `acp` runtime. The pi SDK (`@earendil-works/pi-coding-agent` and `@earendil-works/pi-ai`) is declared under `optionalDependencies` of `@botiverse/oar` (and direct `dependencies` of `@botiverse/oar-cli`): it installs by default, and hosts that want a slim install without Pi can opt out with `npm install --omit=optional` (`pnpm install --no-optional`; note that this omits every optional dependency in the dependency tree, not only Pi's). Without those packages, Pi remains in `defaultRuntimes` and its `installation()` reports `unsupported` with `code: "dependency_missing"`. `@cursor/sdk` is an optional peer dependency, and cursor is not in `defaultRuntimes`: install the SDK (`npm install @cursor/sdk@1.4.1`) and hand it over, `createRuntimeRegistry([...defaultRuntimes.list(), createCursorRuntime({ sdk: () => import("@cursor/sdk") })])`. Written in your code, that import fails your compile if the package is missing. It is Cursor's own package under Cursor's terms, and it signs in with `CURSOR_API_KEY` or its own `Cursor.auth.login()`. `createCursorRuntime({ execution: "subprocess", sdkModule: import.meta.resolve("@cursor/sdk") })` instead runs the SDK in a Node child per session, which takes `SessionOptions.env` and whose crash is recorded as `exited` ([execution modes](https://github.com/botiverse/oar/blob/main/docs/runtimes/cursor.md#execution-modes)).

Community runtimes are contributed and maintained outside the core team (each maintainer is named on its runtime page). They ship in this package from a separate entry point, `@botiverse/oar/community`, and are not in `defaultRuntimes`: `createRuntimeRegistry([...defaultRuntimes.list(), createMorphRuntime()])` adds [Mister Morph](https://github.com/botiverse/oar/blob/main/docs/runtimes/morph.md), driven through its Console Runtime API, and `createCybionRuntime({ baseUrl, apiKey })` adds [Cybion](https://github.com/botiverse/oar/blob/main/docs/runtimes/cybion.md), which drives a server-side Thread through its Agent API. The `oar` CLI adds Mister Morph; it leaves Cybion out, because a Cybion runtime needs a deployment URL and an API key that only the embedding host has.

**Pi Azure provider (since Pi 1.0.3):** the provider is `azure`, not
`azure-openai-responses`; use that prefix in native provider configuration and
`SessionOptions.model`. When resuming an old Azure session, pass
`model: "azure/<model>"` explicitly; without it, Pi can retain the
conversation while selecting a different default model. The opening `model`
event and `Session.model()` report the effective selection. OAR's `~1.6.0`
dependency range includes this change
([migration evidence and limits](https://github.com/botiverse/oar/blob/main/experiments/runtime-version-checks/2026-10-05.md)).

**Pi 1.5.0 default prompt:** the bundled native default system prompt has
changed. Hosts that need stable wording should pass their own `systemPrompt`.
The coding SDK and OAR share undici 8.12.4; see the
[security update evidence](https://github.com/botiverse/oar/blob/main/experiments/pi-1.5.0-2026-11-02.md).

Qwen Code is available as `qwenRuntime` and in `defaultRuntimes`. Install
`@qwen-code/qwen-code` separately. The async `createQwenProviderAuth(installation,
{ cwd?, env?, timeoutMs? })` factory exposes native provider `listProviders()`
and `connect()` operations; environment-based provider configuration also works.
Its `existingConfig` is settings metadata, and connect success confirms a
configuration write, not remote credential validity. Qwen owns the write scope.
It uses stream-json with a held, withdrawable queue and no steer. Structured
output, images, service tier and name are refused; resumed token totals remain
unknown without a native baseline. See its [runtime mapping](https://github.com/botiverse/oar/blob/main/docs/runtimes/qwen.md),
including the cold HOME startup restriction for concurrent sessions.
`qoderRuntime` (Qoder's native SDK daemon protocol from 1.1.81, one process per session)
and `codebuddyRuntime` (CodeBuddy Code's ACP server) are in `defaultRuntimes`
too; see the [Qoder](https://github.com/botiverse/oar/blob/main/docs/runtimes/qoder.md)
and [CodeBuddy](https://github.com/botiverse/oar/blob/main/docs/runtimes/codebuddy.md) mappings.
`dshRuntime` (DeepSeek Harness through a private plugin on its native services, one
process per session, `dshRuntime.minVersion` `0.2.1-rc.5` or later) is too; it selects
models as `provider/model`, takes stdio session MCP servers, and supports native
session names, tool denial, and literal system prompt replacement and append.
Supply prompt and tool-denial options on every resume; native child agents use
their own defaults. Other session options stay refused until probed ([mapping](https://github.com/botiverse/oar/blob/main/docs/runtimes/dsh.md)).
`devinRuntime` (Devin CLI's `devin acp`, isolated process per session) is in
`defaultRuntimes` too; it reads `authStatus` and `distribution` update markers,
attaches stdio/HTTP session MCP entries, switches model and effort synchronously
via `session/set_config_option`, and enforces the saved directory via `session/list`
([mapping](https://github.com/botiverse/oar/blob/main/docs/runtimes/devin.md)).

`hermesRuntime` (Hermes Agent's `hermes acp`, an ACP v1 viewer of the Hermes
gateway daemon) is in `defaultRuntimes` too. The gateway owns turns, tools,
provider credentials and persistence; OAR maps a gateway session to a `Session`,
sets model and effort through the advertised config selectors, maps a missing
resume target to `SessionNotFoundError`, and lists models from the gateway's
picker. It exposes no steer, no manual compaction and no task projection
([mapping](https://github.com/botiverse/oar/blob/main/docs/runtimes/hermes.md)).

`factoryRuntime` (Factory's `droid exec` stream-jsonrpc, one process per session) is
too: droid's own steering, an OAR-held queue, models and effort read back from droid,
and sign-in, status and logout through droid's ACP entry. Install `droid` separately
([mapping](https://github.com/botiverse/oar/blob/main/docs/runtimes/factory.md)).

The command-line interface is a separate package: `@botiverse/oar-cli`.

`Runtime.execution` is a readonly declaration available before installation or
session open: `"process"`, `"in_process"` or `null` when undeclared (including
Morph). It is independent of the installed version and stays the same after
`withPlacement()`. Pi's SDK, Cursor and Pi Durable declare `"in_process"`.
`createPiRuntime({ execution: "subprocess" })` runs one native Pi RPC process
per session instead and declares `"process"`
([Pi RPC process](https://github.com/botiverse/oar/blob/main/docs/runtimes/pi.md#optional-native-rpc-process)).
A host that wants no process sharing uses:

```ts
const selected = runtime.execution === "process" ? runtime.withPlacement("isolated") : runtime;
```

This preserves SDK and undeclared runtime instances. `null` does not promise
isolation; explicit process placement is still refused for those adapters.
No built-in runtime is admitted to shared placement in this release: under
`auto` a process runtime opens an isolated process, and explicit `shared` is
refused at open with `UnsupportedOptionError` (`option: "placement"`). OpenCode
(including native 2.2.3 and 2.2.5, withdrawn in 0.83.0,
[#587](https://github.com/botiverse/oar/pull/587)) and Grok are refused
because configured plugins (OpenCode) or stdio MCP servers (Grok) would start
their child processes in the shared process's HOME instead of the session cwd.
`Runtime.placement` is the requested policy, while `Session.placement` reports
the opened session's actual placement. See the
[placement contract](https://github.com/botiverse/oar/blob/main/docs/spec/record-stream.md#placement-and-release).

What a runtime cannot honor is refused, never dropped: `runtime.session()`
rejects with an `UnsupportedOptionError` (`option` names the refused
`SessionOptions` key, the message is the reason), so a host can try and fall
back on it. `runtime.refusedSessionOptions` names the options a runtime
refuses at open, each with the reason, so a host can leave them out before
opening. One key names a value rather than an option: `mcpServerCredentials`,
an `mcpServers` entry carrying `env` or `headers` (below). Some refusals
depend on the value or operation: Kimi, OpenCode, Antigravity, Devin,
Factory and DSH refuse a `resume` in another directory than the session's own
(the first four also one whose directory `session/list` cannot confirm)
with `ResumeCwdError` (an `UnsupportedOptionError` with `option: "cwd"`, whose
`name` stays `"UnsupportedOptionError"`), carrying `sessionId`,
`requestedCwd`, a typed `reason` and, for `other_cwd`, `savedCwd`
([resume in another directory](https://github.com/botiverse/oar/blob/main/docs/runtimes/resume-cwd.md)). See
[refused session options](https://github.com/botiverse/oar/blob/main/docs/spec/runtime-matrix.md#refused-session-options).

Where an adapter confirms the requested `model` from native readback, an
open (or resume) it cannot confirm rejects with `ModelConfirmationError` (`requested`, `reported`,
and `catalogSelectorIds` when a catalog was read); it is not a
`FailureClass` and not evidence that the model is unavailable. See
[model confirmation failures](https://github.com/botiverse/oar/blob/main/docs/spec/runtime-matrix.md#model-confirmation-failures).

`runtime.resumedSessionOptions` declares measured behavior for accepted
options on resume: when a different supplied value takes effect, and whether
omission uses saved or default settings. Missing entries mean untested.
Claude prompt changes and Codex appended instructions take effect after
native compaction, so pass the current prompt on every resume to retain it
there. See [resume semantics](https://github.com/botiverse/oar/blob/main/docs/spec/runtime-matrix.md#resumed-session-options).

A missing resume target rejects with `SessionNotFoundError` on verified native
signals, carrying `sessionId` and a redacted `cause: { method, native }`.
Other failed opens retain their own errors. Missing is scoped to the runtime's
configuration and, for Pi/Grok, the supplied cwd; save and reuse the cwd with
the id. See [missing resume targets](https://github.com/botiverse/oar/blob/main/docs/spec/runtime-matrix.md#missing-resume-targets).
A target the runtime keeps but will not open now rejects with
`SessionUnavailableError`, whose `reason` is `archived` (the user archived it
in their app; OAR never unarchives it) or `in_use` (another process, such as
the user's app, holds it); codex reports both. See
[unavailable resume targets](https://github.com/botiverse/oar/blob/main/docs/spec/runtime-matrix.md#unavailable-resume-targets).

`SessionOptions.name` is the session's display name in the runtime's own UI
(claude, codex, pi, dsh, and cybion for new threads; other runtimes refuse it). A new session gets it; a
resume never replaces a name the session has. See
[session name](https://github.com/botiverse/oar/blob/main/docs/spec/runtime-matrix.md#session-name).

`SessionOptions.fork` with `resume` opens a NEW session that starts as a
copy of the saved one, leaving the original untouched; `Session.id` is the
copy's. `fork.through` keeps only the turns through one turn: pass the
`forkAnchor` of that turn's root `turn_ended` event (`ViewTurn.forkAnchor` in
the session view); a turn without one cannot be a cut point (claude names
none for a turn that ends on a tool call or was aborted). Claude and Codex
support anchored copies (`through` from Codex 0.143.0). OpenCode v2 supports
whole-session copies when ACP advertises `fork` and refuses `through`. See
[forking a session](https://github.com/botiverse/oar/blob/main/docs/spec/runtime-matrix.md#forking-a-session).

`SessionOptions.additionalDirectories` adds native workspace paths, resolved
relative to `cwd`. Claude, Codex, Cursor, Kimi (new sessions only),
OpenCode v2, Qwen, Qoder and DSH 0.2.2-rc.3+ (Linux and macOS) support it; other runtimes refuse it. Empty or omitted adds no
override. It keeps the primary `cwd` and does not change the sandbox mode.
Project rules or instruction files in those directories may or may not load:
the option does not guarantee it. Resume and configuration rules differ by runtime; see
[additional directories](https://github.com/botiverse/oar/blob/main/docs/spec/runtime-matrix.md#additional-directories).

`SessionOptions.userConfiguration: "exclude"` skips user-level plugins,
skills, commands, agents, MCP servers, hooks, memory and settings while
keeping the native login and session history, so a host can offer a clean
configuration without a new login or losing resume. It is not a sandbox, and
project configuration stays runtime-specific. Claude and Cursor support it;
other runtimes refuse it. On Claude, `{ exclude: ["instructions"] }` leaves
settings and MCP active. You can combine `settings`, `mcp` and `instructions`.
Give the option again on resume. See
[user configuration](https://github.com/botiverse/oar/blob/main/docs/spec/runtime-matrix.md#user-configuration).

`SessionOptions.endTurnProcessesOnAbort: true` (Codex in an isolated
app-server, and Grok; other runtimes and Codex in shared placement refuse it)
makes an accepted `abort()` also end the processes that turn started, where
the native interrupt leaves them running. Codex compares process-table reads;
Grok stops the terminals OAR hosted for that turn. MCP servers and earlier
background commands are kept with what they start, and the session stays
usable. A `cleanup` response on the abort request says what happened. On
Codex a failed or unfinished process-table read ends nothing, and so does
Windows, which has no process groups to tell them apart; Grok uses a
process-tree kill there, not yet run. See
[ending a turn's processes](https://github.com/botiverse/oar/blob/main/docs/spec/runtime-matrix.md#ending-a-turns-processes-on-abort),
[Codex](https://github.com/botiverse/oar/blob/main/docs/runtimes/codex.md#ending-a-turns-processes-on-abort)
and [Grok](https://github.com/botiverse/oar/blob/main/docs/runtimes/grok.md#ending-a-turns-processes-on-abort).

`SessionOptions.outputSchema` supplies a JSON Schema object for final output.
Claude and Grok report their native validated value on a completed
`TurnOutcome.structuredOutput`; `promptAndWait`, status and SessionView
preserve it. Codex sends the schema to its provider but returns text only;
OAR never parses or validates that text. Give the schema again on resume.

```ts
import { defaultRuntimes, promptAndWait } from "@botiverse/oar";

const runtime = defaultRuntimes.require("claude");
const installation = await runtime.installation?.();
if (installation?.kind !== "available") throw new Error("Claude unavailable");
const session = await runtime.session(installation, {
  cwd: process.cwd(),
  outputSchema: {
    type: "object", properties: { answer: { type: "integer" } },
    required: ["answer"], additionalProperties: false,
  },
});
try {
  const run = await promptAndWait(session, "What is 2 + 2?");
  if ("outcome" in run && run.outcome.kind === "completed" && "structuredOutput" in run.outcome) {
    console.log(run.outcome.structuredOutput);
  }
} finally { await session.dispose(); }
```

Even with a schema, Claude may complete without `structuredOutput`; check
the field's presence as well as the outcome. Other core runtimes refuse
`outputSchema` at open. Where each runtime applies the schema, and how it
fails: [structured output](https://github.com/botiverse/oar/blob/main/docs/spec/runtime-matrix.md#structured-output).

`SessionOptions.mcpServers` attaches MCP servers (stdio `{name, command,
args?, env?}` or streamable HTTP `{name, type: "http", url, headers?}`) to
one session alongside the runtime's configured servers. Supply the entries
again on `resume`. Claude reads them from a 0600 FIFO or, on Windows, a
0600 temporary file deleted immediately after `initialize`. DSH receives
stdio entries with `env` and HTTP entries with `headers` through bridge stdin.

The `pi-durable`, `morph` and `cybion` runtimes refuse `mcpServers`.
OAR keeps entry `env` and `headers` values out of records and errors.
Antigravity, Devin and Cybion declare `mcpServerCredentials` when
refusing entries that carry these values. Every runtime refuses the
names `__proto__`, `__defineGetter__`, `__defineSetter__`, `__lookupGetter__`
and `__lookupSetter__` (`option: "mcpServers"`), which some runtimes drop
without a word. See the
[channels](https://github.com/botiverse/oar/blob/main/docs/spec/runtime-matrix.md#refused-session-options)
and each runtime page's "Session MCP servers".

Tools the host implements itself go through the same option. `serveMcpTools`
serves them from an MCP server inside the host process and returns the
`mcpServers` entry to pass, so one implementation reaches every runtime that
takes an `http` entry with `headers` (check
`installedSessionCapabilities(runtime, installation)` for `mcpTransports` and
`mcpServerCredentials`):

```ts
import { serveMcpTools } from "@botiverse/oar";

const served = await serveMcpTools({
  name: "workspace",
  tools: [{
    name: "read_note",
    description: "Read a note from the host's store",
    inputSchema: { type: "object", properties: { id: { type: "string" } }, required: ["id"] },
    handler: async ({ id }, { signal }) => await notes.read(String(id), { signal }),
  }],
});
const session = await runtime.session(installation, { cwd, mcpServers: [served.server] });
// ... later, after the sessions that use it are disposed:
await served.close();
```

It listens on 127.0.0.1 behind a random bearer token (in the entry's
`headers`, so it never appears in a record), so the runtime must run on this
machine, as OAR's runtimes do. A handler returns text, or MCP content with
`isError` for a failed call; a thrown error becomes an `isError` result with
its message. Its `signal` aborts when the runtime cancels the call or the
server closes. A tool's MCP `annotations` (`readOnlyHint`, `destructiveHint`,
...) go out unchanged in `tools/list`; runtimes may use them (for approval, for
example); OAR neither validates nor acts on them. One served set can back several sessions. `instructions` (guidance
across the tools) goes out as the MCP server instructions; claude, codex,
opencode and grok show them to the model, pi and kimi do not.
`served.setTools(tools)` replaces the tools while sessions run and sends MCP's
`notifications/tools/list_changed`. Whether a running session's model sees
the change is the runtime's choice, declared before opening as
`runtime.mcpToolsListChanged`: `full` (pi, opencode), `additions` (claude:
new tools appear, removed ones stay offered) or `none` (codex, kimi, grok, antigravity),
absent where unmeasured; a session that does not take it gets the new tools when the host opens its next
session. The declaration covers any MCP server that announces a change, so
antigravity declares `none`, though a served entry never attaches there. See
[host-served tools](https://github.com/botiverse/oar/blob/main/docs/spec/runtime-matrix.md#host-served-tools).

`runtime.minVersion`, when present, declares the adapter's minimum native
version; it never installs or upgrades anything. Readers independently enforce
their path's requirement, even when called without `installation()` first.
A version refusal carries optional `installedVersion` and `requiredVersion`:
model listing, installation and inventory use `unsupported.code:
"version_unsupported"`; account usage uses that `reason`; authentication status
uses `unknown` with that `code`. Pi's custom-command floor applies to RPC,
not reads through its bundled SDK. A version-refused installation also retains
its executable `command` and `via`, so a host can pass it to `checkUpdate` or
`upgrade`; re-probe for availability before opening a session. See
[version requirements](https://github.com/botiverse/oar/blob/main/docs/spec/orientation.md#adapter-version-requirements).

`runtime.listModels(installation, options?)` lists the models an installation
can run now (`ok`, `unauthenticated` or `unsupported`); every built-in runtime
has it. Entries include native `effortLevels` and `serviceTiers` where supported.
`effortUnavailableReason` distinguishes a menu that could not be determined from
a runtime that has no effort menu; it does not mean the model is disabled.
`default: true` marks the model a session uses when no `model` is set, where
the runtime says so (codex's configured model, else its catalog default; a new
session's current model on grok, kimi, antigravity, codebuddy and devin; the native
default on qoder and dsh; the default saved in pi's settings). claude, cursor,
opencode, qwen and factory mark none: OAR never picks one.
Where several providers serve models (pi, opencode v1, dsh), `provider: { id,
displayName? }` says which (OpenCode v2 omits `provider`), so a host never parses `id`. A project's own
configuration can change the list and its default, so pass `options.cwd`, the
directory a session would run in (the host's cwd by default). Like the
inventory readers, listing starts the runtime there the way a session would
and can run that workspace's code (pi loads the project's extensions), so do
not list in a directory you do not trust.
`SessionOptions.serviceTier` applies at open (also on resume) and is checked
against the runtime's own report. Use `default` to explicitly clear a tier;
it is not a model catalog entry. `Session.serviceTier()` reports the effective
tier. Unsupported runtimes reject the option before opening.
`runtime.accountUsage(installation)` reads account quota on antigravity,
claude, codex, factory, grok and kimi; its failure semantics are in the
[account usage reference](https://github.com/botiverse/oar/blob/main/docs/spec/account-usage.md).
On codex it also reports the account's limit resets, and
`runtime.redeemLimitReset(installation, { idempotencyKey })` spends one.
Claude has them only in its interactive UI: `runtime.inspectLimitResets`
lists them and `redeemLimitReset` with a `resetId` kind spends one, by
driving that UI on the person's request, never polled. oar never spends one
on its own
([limit resets](https://github.com/botiverse/oar/blob/main/docs/spec/account-usage.md#limit-resets)).

`runtime.checkUpdate(installation)` reports the version the runtime's own
updater would install and where that answer came from;
`runtime.upgrade(installation)` runs that updater without a terminal and
judges the result by the version the same executable reports afterwards,
never by its exit code. oar never upgrades on its own. Claude, Codex, Factory, Grok, Kimi
and Antigravity have both; Devin has only the check; OpenCode has only `upgrade`
(v2); CodeBuddy, DSH, Qwen and Qoder have neither yet; Pi, Cursor, Pi Durable,
Mister Morph and Cybion have neither (Pi's SDK is an optional dependency and
Cursor's an exact peer dependency).
See [runtime updates](https://github.com/botiverse/oar/blob/main/docs/spec/update.md).

`runtime.installPlan()` reports what installing a runtime would run on this
machine (the vendor's documented installer and the page that documents it)
or why it would run no installer (`platform`, `requires_privileges`,
`requires_gui`, `missing_tool`, `location_unknown`, `configuration`; `requires_privileges`, `missing_tool` and `location_unknown`
still carry the vendor's `steps` and `source`, for the person to run
themselves once they have the rights or the tool, or have checked the installer's
location configuration); `runtime.install()` runs
it, without a terminal and never with sudo, when `installation()` finds no
copy, and judges the result by `installation()` afterwards, never by the
installer's exit code. oar never installs on its own. Claude, Codex, Factory, Grok,
Kimi, OpenCode, Qwen, Qoder, Antigravity and Devin install through their vendors' macOS and Linux scripts;
CodeBuddy and DSH use their official npm packages on Linux, macOS and Windows
and check the configured global prefix; CodeBuddy's launcher is discovered even
off PATH.
Planning may run bounded local read-only queries with private temporary files
removed afterwards; it never installs, downloads packages or changes user files.
An unreadable prefix returns `location_unknown` with the failure category in
`detail`, without npm's raw output.
OpenCode declares two release lines in `runtime.installLines` (`v1`, `v2`)
and takes the host's choice as `line` (oar picks none), and a copy of either
line is `already_installed`, never replaced. Antigravity uses `agy acp` from
CLI 1.5.0 or newer, discovered on PATH or in the official install directory;
its Windows plan provides the manual PowerShell command. An old selected CLI
or missing pinned path must be corrected first (`configuration`), because the
vendor installer does not replace it. Devin installs via its standalone shell
script (rejecting an existing regular non-symlink file at `~/.local/bin/devin`)
and returns the documented PowerShell command on Windows. Pi and Cursor have
neither member.
See [runtime install](https://github.com/botiverse/oar/blob/main/docs/spec/install.md).

`runtime.login(installation, interaction)` logs an installation in through
the runtime's own login, without a terminal: the sign-in URL or device code
arrives as a `ProviderLoginInteraction` event, and a code the person pastes
back is answered through its `manual_code` prompt and written to the
runtime's stdin only. It never logs the current account out first, and
`interaction.signal` cancels it. `runtime.authStatus(installation)` reads the
runtime's own status, never a secret, and never starts a login; a status read
past its `timeoutMs` returns `unknown` without waiting for process cleanup.
Claude, Codex, Cursor (through its SDK's own `Cursor.auth`), Kimi (`kimi
login`, with `KimiLoginOptions.region`), Grok (`grok login --device-auth`),
Antigravity (its own `agy acp --login`, with the person pasting the code
back), Factory (droid's device pairing on its ACP entry), CodeBuddy and Qoder have both. Qwen and Devin have only `authStatus`:
Qwen checks local provider configuration (its provider settings are on
`createQwenProviderAuth`), while Devin reads `devin auth status` and flags
`WINDSURF_API_KEY`. OpenCode, DSH and Pi have neither (Pi's
provider logins are on `createPiProviderAuth`, OpenCode 2's on
`createOpencodeProviderAuth`). Antigravity's vendor warns that third-party
access with a consumer login may break its terms; see
[login](https://github.com/botiverse/oar/blob/main/docs/runtimes/antigravity.md#login).
`runtime.logout(installation)` signs Claude, Codex, Cursor, Kimi, Grok,
Antigravity, Factory and CodeBuddy out through their own logout (`claude auth
logout`, `codex logout`, `Cursor.auth.logout`, Kimi's, Antigravity's and droid's ACP
`logout`, `grok logout`, CodeBuddy's stream-json `logout`); Qoder has no
non-interactive logout. It resolves `logged_out` when
`authStatus` then reads logged out (or, when it cannot tell, on the
runtime's own report of success); an API key in the environment is not
touched, and one the status still reads is `failed` / `still_logged_in`.
`login`, `logout` and `authStatus` take an `env` overlay like
`SessionOptions.env` (pass the session's map; refused where sessions refuse
`env`), and `login` takes `openBrowser: false` to keep the runtime from
opening a browser on this machine. `userShellEnvironment()` reads the user's
login-shell environment once, only when the host calls it, as an `env` map
that contains secrets ([environment](https://github.com/botiverse/oar/blob/main/docs/spec/login.md#environment)).
See
[runtime login](https://github.com/botiverse/oar/blob/main/docs/spec/login.md).

Images go with an input through `InputOptions.images` (`{ path }` entries:
absolute paths to png, jpeg, gif or webp files) on prompt, steer and queue,
as the runtime's own image content. `session.capabilities.images` says whether
the runtime takes them; an input it cannot deliver is rejected whole. See
[Images](https://github.com/botiverse/oar/blob/main/docs/spec/conversation.md#images).

TypeScript hosts: keep `skipLibCheck` on when Pi or Cursor is installed. With `npm install --omit=optional` (and no optional peers), OAR's own declarations check clean even with `skipLibCheck: false` and `module: nodenext`. With Pi installed (`skipLibCheck: false` and `module: nodenext`), TypeScript reports errors inside the pi SDK's declarations and their dependencies' (`@earendil-works/pi-ai` imports JSON without an import attribute, TS1543; its `@google/genai` imports the optional peer `@modelcontextprotocol/sdk`, TS2307, and without the DOM lib also misses `RequestInfo` and `HeadersInit`); OAR's own declarations check clean (official TypeScript 6.0.3 consuming a clean install of the tsrs-built package). A host that installs `@cursor/sdk` and checks library files also needs the DOM lib for its `@connectrpc/connect` dependency (`HeadersInit`).

## Host-owned durable sessions

Install the optional native peers in the host: `npm install @earendil-works/pi-durable@~1.6.0 @earendil-works/chord@~1.6.0`.
Resolve Durable and Chord to exactly the same version.
For the host catalog, keep `@earendil-works/pi-ai@1.6.0` under its normal
name and add `@earendil-works/pi-ai-durable` as an npm alias of Pi AI 1.6.0;
import Durable models/providers from that alias. See the
[copyable host configuration](https://github.com/botiverse/oar/blob/main/docs/runtimes/pi-durable.md#native-objects-and-calling-interface).
Using a different Pi AI version under its normal name can split the coding
SDK's registration instances and break OAuth loading in single-file hosts.
The native peers support `pi.live` document version 3 and the group-commit
Storage interface. Back up storage before upgrading from 1.4: once new work
is committed under 1.5, that storage cannot be reopened by 1.4. Rollback
requires restoring the pre-upgrade backup. The host owns storage compatibility; see the
[host requirements](https://github.com/botiverse/oar/blob/main/docs/runtimes/pi-durable.md#native-objects-and-calling-interface).
The factory lives only in `@botiverse/oar/pi-durable`, usable in Node and browsers.
The root and browser core entries load without these peers.

```ts
import { initialSessionView, reduceSessionView } from "@botiverse/oar/browser";
import { createPiDurableRuntime } from "@botiverse/oar/pi-durable";

// Use the same Models instance or () => Models supplier passed to Harness.open.
const runtime = createPiDurableRuntime({ harness, models });
const session = await runtime.session({ kind: "available", via: "bundled" }, {
  cwd: "/workspace", model: "provider/model",
});
let view = initialSessionView(session.id);
session.rawEvents(record => {
  view = reduceSessionView(view, record, session.id);
  render(view);
}, { sessionId: session.id, afterSeq: -1 });
await session.prompt("Hello", { inputId: crypto.randomUUID() });
```

The host owns its Pi Durable 1.6.0 Harness, providers, credentials, extensions
and storage. `resume: session.id` attaches to that storage's conversation and
resumes unfinished work. Queue and input-id deduplication are native and
durable. `dispose()` detaches the observer; it does not stop work or close the
Harness. Use `abort()` to stop a run. The portable entry needs Web Crypto.
See [Pi Durable](https://github.com/botiverse/oar/blob/main/docs/runtimes/pi-durable.md)
for configuration, snapshot and recovery semantics. This constructor is not
in the default registry or CLI.

## Native inventories

Every runtime exposes `skills(installation, options?)`,
`commands(installation, options?)`, `mcpServers(installation, options?)`, and `tools(installation, options?)`.
Options are `{ cwd?: string, timeoutMs?: number, env? }` (`env` is the
`SessionOptions.env` overlay); cwd defaults to `process.cwd()`. Queries discover native information independently: they do
not inspect an existing Session or submit a model prompt, though native
startup can load extensions and connect configured MCP servers.

Results distinguish `ok`, `unsupported`, and `unavailable`. Successful results
contain `items`, `scope.cwd`, `observedAt`, `view`, and `partial`. A
`mcp-only` view excludes built-in tools. Unknown schema or state fields stay
absent, and an unsupported query never pretends to be an empty catalog.

Codex and Claude expose skills and MCP discovery (tools are MCP-only); Grok
exposes independent skills and MCP configuration discovery; Pi exposes skills
and registered tools with active membership. Pi commands include extension
commands and prompt templates; Claude commands come from native initialize.
Other core runtimes return unsupported for independent command discovery.
Kimi and OpenCode expose native skill catalogs. Cursor discovers the measured
SDK user/project skill directories with `view: "discovered"`, without loading
hooks or MCP servers; malformed/unreadable metadata makes the result partial.
Antigravity, Devin, DSH, Factory and Qwen expose `skills` (`commands`,
`mcpServers` and `tools` unsupported); CodeBuddy, Qoder, Cybion, Pi Durable
and Mister Morph inventory queries are all unsupported.

```ts
const catalog = await runtime.commands(installation, { cwd: "/my/project" });
if (catalog.kind === "ok") {
  for (const command of catalog.items) {
    console.log(command.name, command.description, command.argumentHint);
  }
}
```

Command entries use native invocation names (Pi resolves duplicate extension
names itself), with optional source and aliases. Skills stay in `skills()`;
hosts merge catalogs for a picker. Claude's native catalogs can overlap.
This is discovery, not execution or a live session's command state.
[Command scope and limits](https://github.com/botiverse/oar/blob/main/docs/spec/inventory.md#commands).

Custom runtimes should use `defineRuntime`, which fills missing inventory
methods with explicit unsupported results and supplies `execution`, `placement`
and `withPlacement`. Its second argument's `execution` controls both the public
declaration and placement selection; omission gives `null`. Supplying `shared`
hooks requires `execution: "process"`, checked by the type and at runtime.
A manually constructed `Runtime` must implement the four inventory methods, including
`commands`, and these placement members.

### Orientation

`orient(registry, { depth: "local" | "account" | "models", runtimes?, env?, timeoutMs?, signal? })`
combines existing readers into timestamped probes, preserving missing and failed
evidence. Local is the default and skips auth readers without a proven local
query. Account reads can refresh credentials or execute configured key commands;
models can start native processes and run trusted configuration.
`include: ["customization"]` explicitly opts into native inventory counts.
Hosts derive readiness from the returned probes using their own freshness
and selection policy.
See [orientation](https://github.com/botiverse/oar/blob/main/docs/spec/orientation.md).

### Runtime branding

`runtime.brand` contains `{ name, icon }`. Built-in icons are self-contained SVG
data URIs, usable as an `<img src>` offline and serializable across IPC.
Reading branding needs no installation, login, or runtime process. Browser-only
consumers can read it without loading native SDKs:

```ts
import { runtimeBrands } from "@botiverse/oar/brands";
const { name, icon } = runtimeBrands.claude;
```

The SVG files' attribution and licenses ship in `assets/brands/NOTICE.md`; Pi
uses the official `pi.dev` logo assets. Custom runtimes created with
`defineRuntime` may supply `brand`; otherwise it defaults to
`{ name: runtime.id, icon: null }`. Runtime branding identifies the provider
and is independent of an application's project avatars.

`brand.icons?.light` and `brand.icons?.dark` optionally override the default
for light and dark **backgrounds**; they need not be distinct or both present.
`runtimeBrandIcon(brand, theme)` returns the matching variant, falling back to
`brand.icon` (null for brands without artwork). Hosts choose the theme from
their own surface, not necessarily the operating system setting.

```ts
import { runtimeBrands, runtimeBrandIcon } from "@botiverse/oar/brands";
const src = runtimeBrandIcon(runtimeBrands.codex, "dark");
```
